import { useState } from 'react'

// Css
import './App.css'


function App({children}) {
  return (
    <>{children}</>
);
}

export default App